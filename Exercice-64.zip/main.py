motif = "dernière"
lm = len(motif)

sauts = {chr(i):lm for i in range(256)} #On se prend toute la table ASCII.

texte = "test"

with open("BoyerMoore.txt","r") as fichier:
	texte = fichier.read()
  
def Recherche(txt, pat):
    m = len(pat) 
    n = len(txt) 
    
    p = 0
    while(p <= n-m): 
        q = m-1
  
        while q>=0 and pat[q] == txt[p+q]: 
            q -= 1
  
        if q<0: 
            print("Mot au point = {}".format(p))
            p += (m-sauts[txt[p+m]]+1 if p+m<n else 1)

        else:
            p += max(1, q-sauts[(txt[q+q])]) 

Recherche(texte, motif) 