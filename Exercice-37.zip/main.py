commandes={'read':'R','write':'W','execute':'X'}
fichiers={}

with open("accessRights.txt","r") as ar:
    for ligne in ar:
      a=ligne.split()
      fichiers[a[0]]=""
      for item in a:
        if item in ["R","W","X"]:
          fichiers[a[0]]+=item

print(fichiers)

with open("operations.txt","r") as op:
  for line in op:
    a = line.split()
    if commandes[a[0]] in fichiers[a[1]]:
      print(a[1]+"for"+a[0]+" : ok")
    else:
      print(a[1]+"for"+a[0]+" : access denied")
