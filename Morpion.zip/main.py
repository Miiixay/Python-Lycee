from random import randint,choice
import pygame
from pygame.locals import*


pygame.init()  #initialisation de pygame
fenetre = pygame.display.set_mode(
    (300,300), FULLSCREEN
)  #taille de la fenêtre. On peut mettre FULLSCREEN pour être en plein écran.

class image():
    def __init__(self, image, x=0, y=0):
        self.image = pygame.image.load(
            image).convert_alpha()  # chargement du sprite
        self.image=pygame.transform.scale(self.image,(80,80))
        self.x = x
        self.y = y

croix=image("croix.png")

rond=image("rond.png")

class Grille():
  def __init__(self):
    self.grille=[' ' for i in range(10)] #Initialisation de la grille. ' ' pour case vide.
    self.winner=None

  def __str__(self): #Pour afficher une grille toute moche
    return f"""\033[2J\033[1;1H\n   |   | 
  {self.grille[1]}| {self.grille[2]} |{self.grille[3]}
  ---------
  {self.grille[4]}| {self.grille[5]} |{self.grille[6]}
  ---------
  {self.grille[7]}| {self.grille[8]} |{self.grille[9]}
   |   |"""

  def placeGrille(self,t,p): #Place un symbole sur la grille. Renvoie faux si la case est non vide.
    if self.grille[p]==" ":
      self.grille[p]=t
      if self.win():
        self.winner = t
      return True
    return False
    

      
  def win(self): #Vérifie que la grille actuelle a une victoire et renvoie le symbole victorieux le cas échéant.
    if self.grille[1]== self.grille[2] and self.grille[2]==self.grille[3] and self.grille[1]!=" ":
      return True
    if self.grille[4]== self.grille[5] and self.grille[4]==self.grille[6] and self.grille[4]!=" ":
      return True
    if self.grille[7]== self.grille[8] and self.grille[7]==self.grille[9] and self.grille[7]!=" ":
      return True
    if self.grille[1]== self.grille[4] and self.grille[1]==self.grille[7] and self.grille[1]!=" ":
      return True
    if self.grille[2]== self.grille[5] and self.grille[2]==self.grille[8] and self.grille[2]!=" ":
      return True
    if self.grille[3]== self.grille[6] and self.grille[3]==self.grille[9] and self.grille[3]!=" ":
      return True
    if self.grille[1]== self.grille[5] and self.grille[1]==self.grille[9] and self.grille[1]!=" ":
      return True
    if self.grille[3]== self.grille[5] and self.grille[3]==self.grille[7] and self.grille[3]!=" ":
      return True
    return False

  def legit(self): #Renvoie les cases libres.
    res=[]
    for i in range(1,10):
      if self.grille[i]==' ':
        res.append(i)
    return res

def Choix():
  while True:
    for event in pygame.event.get():
         if event.type == MOUSEBUTTONDOWN:
            if event.button == 1:
              mx, my = pygame.mouse.get_pos()
              if 60<mx<140 and 170<my<250:
                return 'X'
              elif 160<mx<240 and 170<my<250:
                return 'O'



def PosCurseur(mx, my):
  if 0<mx<100 and 0<my<100:
    return [1,PosSymb(1)]
  elif 100<mx<200 and 0<my<100:
    return [2,PosSymb(2)]
  elif 200<mx<300 and 0<my<100:
    return [3,PosSymb(3)]
  elif 0<mx<100 and 100<my<200:
    return [4,PosSymb(4)]
  elif 100<mx<200 and 100<my<200:
    return [5,PosSymb(5)]
  elif 200<mx<300 and 100<my<200:
    return [6,PosSymb(6)]
  elif 0<mx<100 and 200<my<300:
    return [7,PosSymb(7)]
  elif 100<mx<200 and 200<my<300:
    return [8,PosSymb(8)]
  elif 200<mx<300 and 200<my<300:
    return [9,PosSymb(9)]
  
def PosSymb(p):
  if p == 1: return (10,10)
  elif p == 2:return (110,10)
  elif p == 3:return (210,10)
  elif p == 4:return (10,110)
  elif p == 5:return (110,110)
  elif p == 6:return (210,110)
  elif p == 7:return (10,210)
  elif p == 8:return (110,210)
  elif p == 9:return (210,210)
  

class Joueur(): #Super classe de joueur
  def __init__(self,symb):
    self.symb = symb
  
  def joue(self, partie):
    pass

class Humain(Joueur):
  def __init__(self,symb):
    super().__init__(symb) # initialise dans la super classe

  def joue(self,symb): #Jeu du joueur avec toutes les précautions.
    ligne=None
    signe=str
    if symb=='X':
      signe=croix
    else:
      signe=rond
    while True:
      for event in pygame.event.get():
         if event.type == MOUSEBUTTONDOWN:
            if event.button == 1:
              mx, my = pygame.mouse.get_pos()
              res = PosCurseur(mx,my)
              if res[0] in partie.legit():
                signe.x=res[1][0]
                signe.y=res[1][1]
      
                fenetre.blit(signe.image, (signe.x, signe.y))

                pygame.display.update()
                return res[0]

      '''p=input("Où ? ")
      possibles=partie.legit()
      try:
        p=int(p)
        if p<1 or p>9:
          print("Entre 1 et 9")
        else:
          if p not in partie.legit():
            print("Emplacement déjà occupé.")
          else:
            return p
      except:
        print("Un entier entre 1 et 9.")'''

class Cpu(Joueur):
  def __init__(self,symb):
    super().__init__(symb) # initialise dans la super classe

  def joue(self,symb): #L'ordinateur joue au hasard.
    res=choice(partie.legit())
    signe = str
    if symb=='X':
      signe=croix
    else:
      signe=rond
    signe.x=PosSymb(res)[0]
    signe.y=PosSymb(res)[1]

    fenetre.blit(signe.image, (signe.x, signe.y))
    
    pygame.display.update()
    return res
    

  

fond = pygame.image.load("morpion.jpg").convert_alpha()
start= pygame.image.load("StartMorpion.jpg").convert_alpha()
gagne=pygame.image.load("WinMorpion.jpg").convert_alpha()
perdu=pygame.image.load("LoseMorpion.jpg").convert_alpha()
egalite=pygame.image.load("DrawMorpion.jpg").convert_alpha()
rejouer=image("rejouer.png")
quitter=image("quitter.png")
continuer = True

pygame.key.set_repeat(
    100, 25
) 

while continuer:
    fenetre.blit(start,(0,0))
    fenetre.blit(croix.image,(60,170))
    fenetre.blit(rond.image,(160,170))
    pygame.display.update()

    choix=Choix()


    fenetre.blit(fond, (0,0))
    pygame.display.update()
    partie = Grille()

    if choix=='X':
      p1= Humain('X')
      p2 = Cpu('O') #à remplacer par SmartCpu une fois tout bien codé
    else:
      p1=Cpu('X')
      p2=Humain('O')


    current = 'X'

    while (not partie.winner) and len(partie.legit())>0:
      print(partie)
      if current == 'X':
        partie.placeGrille('X',p1.joue('X'))
      else:
        partie.placeGrille('O',p2.joue('O'))
      current = 'O' if current == 'X' else 'X'
      winner = partie.winner

    print(partie)
    
    if (not winner) and len(partie.legit())==0:
      print('Egalité.')
      fenetre.blit(egalite,(0,0))
      pygame.display.update()
    else:
      print(winner+' gagne.')
      if winner==choix:
        fenetre.blit(gagne,(0,0))
        pygame.display.update()
      else:
        fenetre.blit(perdu,(0,0))
        pygame.display.update()
    var=True
    while var:
      fenetre.blit(rejouer.image,(60,170))
      fenetre.blit(quitter.image,(160,170))
      pygame.display.update()
      if Choix()=='X':
        var=False
      elif Choix()=='O':
        var=False
        continuer=False  
pygame.quit()