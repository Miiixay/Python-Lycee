

def frequence_lettre(a):
  nombre = 0
  response = input("Ecrivez une phrase: ")
  for i in response:
    if i == a:
      nombre +=1 
  return nombre

print(frequence_lettre('a'))

def alphabet():
  n = {chr(i+96):0 for i in range(1,27)}
  return n

dico = alphabet()

with open("fichierAlainTuring.txt") as fichier :
  for ligne in fichier : 
    for car in ligne :
      if car in dico:
        dico[car] += 1

print(dico)    


with open("fichierSteveJobs.txt") as fichier :
  for ligne in fichier : 
    for car in ligne :
      if car in dico:
        dico[car] += 1

print(dico)

        
        