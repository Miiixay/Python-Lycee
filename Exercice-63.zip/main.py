recherche = "CGCTTA"
CGCTTA = []

with open("ADN.txt","r") as fichier:
  for ligne in fichier :
    for i in ligne :
      CGCTTA.append(i)

compteur = 0
for j in range(len(CGCTTA)-5) :
  compteur += 1
  if recherche == CGCTTA[j] + CGCTTA[j+1] + CGCTTA[j+2] + CGCTTA[j+3] + CGCTTA[j+4] + CGCTTA[j+5] :
    print(recherche,compteur)