import pygame  #importe la librairie pygame gérant le SDL en Python
from pygame.locals import *  #importe les constantes de pygame directement dans le script

pygame.time.Clock().tick(30) #Maximum 30 f r ame s par sec onde .

pygame.init()  #initialisation de pygame
fenetre = pygame.display.set_mode(
    (640, 480), FULLSCREEN
)  #taille de la fenêtre. On peut mettre FULLSCREEN pour être en plein écran.

#Définition des couleurs:
red = Color(255, 0, 0)
green = Color(0, 255, 0)
blue = Color(0, 0, 255)
white = Color(255, 255, 255)
black = Color(0, 0, 0)

#Définition des paramètres du rectangle :
x, y = 10, 10  # raccourci pour affecter plusieurs variables à la fois
longueur, hauteur = 100, 100



while True:
    rectangle = Rect(
        x, y, longueur, hauteur
    )  # création du rectangle avec sa position, sa largeur et sa hauteur.
    
    center = (x,y) #coordonnées du centre
    radius = 40  #rayon
    width = 40  #largeur de la ligne (même que le rayon pour remplir le cercle)
    
    pygame.draw.circle(fenetre, red,
                     center, radius, width) 
    pygame.draw.circle(fenetre, white, center, radius, 5)

    pygame.display.update()

    fenetre.fill(black)

    pygame.display.update()
    x+=2
    y+=1
